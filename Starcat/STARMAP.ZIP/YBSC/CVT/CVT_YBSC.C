#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <conio.h>

#include "cvt_ybsc.h"
#include "pxengine.h"         // Paradox engine header

// Defines for PXNetInit
#define USERNAME  "CVT_YBSC"
#define NETTYPE   NOTONNET
#define NETDIR    ""

char *BayerTable[25] =
{ "", "Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta", "Eta", "Theta",
  "Iota", "Kappa", "Lambda", "Mu", "Nu", "Xi", "Omicron", "Pi", "Rho",
  "Sigma", "Tau", "Upsilon", "Phi", "Chi", "Psi", "Omega"
};


int Exceptions[14] ={  92,  95, 182,1057,1841,2472,2496,
                     3515,3671,6309,6515,7189,7539,8296 };

#define PXErr(parm)    PXError(__LINE__,parm)

FILE *pIn, *pOut;

RAWREC    rr;
PARSEDREC pr;
REMREC    rm;
char buf[1024];
int rec_cnt=0;
TABLEHANDLE tHdl;
RECORDHANDLE rHdl;

int PXError(int line, int rc)
// if error display message and terminate program
{
   if (rc != PXSUCCESS)
   {
      printf( "\nPARADOX ERROR LINE (%d): %s\n", line, PXErrMsg(rc));
      exit(1);
   }
   return rc;
}

//-------- CLEANUP FUNCTION ---------
void exit_func( void )
{
   fcloseall();
   PXExit();
   printf("\n\n");
}


void blk20( char* p, int len)
{
   for( int i=0; i<len; i++)
   {
      if( *p == ' ' )
         *p = '0';
      p++;
   }
}

double cvt_flt( char* buf, int len, int /*dec*/)
{
   char str[12];
   memcpy( str, buf, len);
   blk20( str,len);
   str[len] = 0;
   return( atof(str));
}

char* cvt_str( char* src, char* trg, int len)
{
   memcpy( trg, src, len);
   trg[len] = 0;
   return(trg);
}

int cvt_int( char* p, int len)
{
   char str[8];
   blk20( p, len);
   memcpy( str, p, len);
   str[len] = 0;
   return( atoi(str));
}

int last_star=0;
char last_cat[5]="";

void xlat_remrec(void)
{
   int star;
   char str[132];

   star = cvt_int( rm.StarNbr, 5);
   if( star == 0 )
      star = last_star;
   else
      last_star = star;
   PXErr( PXPutShort( rHdl, 1, star));

   cvt_str( rm.RemCat, str, 4);
   if(memcmp( str, "    ", 4) == 0)
      strcpy( str, last_cat);
   else
      strcpy( last_cat, str);
   PXErr( PXPutAlpha( rHdl, 2, str));
   PXErr( PXPutAlpha( rHdl, 3, cvt_str( rm.Remark, str, 120)));
}

double deg2rad( double d )
{
   return((3.14159/180) * d);
}

double rad2deg( double r )
{
   return((180/3.14159)* r);
}

void rawrec2buf(void)
{
   char str[32];

   PXErr( PXPutShort( rHdl, 1, pr.StarNbr ));
   PXErr( PXPutDoub(  rHdl, 2, pr.GalLongitude));
   PXErr( PXPutDoub(  rHdl, 3, pr.GalLatitude));

   PXErr( PXPutDoub(  rHdl, 4, pr.Plx));
   if( pr.Plx )
   {
      pr.DstParsecs    = 1/pr.Plx;
      pr.DstLightYears = pr.DstParsecs * 3.26;
      PXErr( PXPutDoub(  rHdl, 5, pr.DstParsecs));
      PXErr( PXPutDoub(  rHdl, 6, pr.DstLightYears));
   }
   else
   {
      PXErr( PXPutBlank( rHdl, 5));
      PXErr( PXPutBlank( rHdl, 6));
   }
   if( pr.GalLongitude || pr.GalLatitude )
   {
      pr.PlotQuad[1] = 0;
      if( pr.GalLongitude >= 0 && pr.GalLongitude < 90 && pr.GalLatitude >= 0 )
         pr.PlotQuad[0] = '1';
      else if( pr.GalLongitude >= 90 && pr.GalLongitude < 180 && pr.GalLatitude >= 0 )
         pr.PlotQuad[0] = '2';
      else if( pr.GalLongitude >= 180 && pr.GalLongitude < 270 && pr.GalLatitude >= 0 )
         pr.PlotQuad[0] = '3';
      else if( pr.GalLongitude >= 270 && pr.GalLongitude < 360 && pr.GalLatitude >= 0 )
         pr.PlotQuad[0] = '4';
      else if( pr.GalLongitude >= 0 && pr.GalLongitude < 90 && pr.GalLatitude < 0 )
         pr.PlotQuad[0] = '5';
      else if( pr.GalLongitude >= 90 && pr.GalLongitude < 180 && pr.GalLatitude < 0 )
         pr.PlotQuad[0] = '6';
      else if( pr.GalLongitude >= 180 && pr.GalLongitude < 270 && pr.GalLatitude < 0 )
         pr.PlotQuad[0] = '7';
      else if( pr.GalLongitude >= 270 && pr.GalLongitude < 360 && pr.GalLatitude < 0 )
         pr.PlotQuad[0] = '8';
      PXErr( PXPutAlpha( rHdl, 8, pr.PlotQuad));
   }
   else
   {
      PXErr( PXPutBlank( rHdl, 8));
   }
   if( pr.Plx && (pr.GalLongitude || pr.GalLatitude) )
   {
      pr.PlotX = 0;
      pr.PlotY = 0;
      pr.PlotZ = 0;
      pr.GalLatitude  = deg2rad(pr.GalLatitude);
      pr.GalLongitude = deg2rad(pr.GalLongitude);
      pr.PlotZ = sin( pr.GalLatitude ) * pr.DstLightYears;
      switch( pr.PlotQuad[0] )
      {
         case '1' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = cos( pr.GalLongitude) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX);
            pr.PlotY = fabs(pr.PlotY);
            break;
         case '2' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( deg2rad(180)-pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = cos( deg2rad(180)-pr.GalLongitude) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX) * -1;
            pr.PlotY = fabs(pr.PlotY);
            break;
         case '3' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( pr.GalLongitude -deg2rad(180) ) * pr.PlotX;
            pr.PlotX = cos( pr.GalLongitude -deg2rad(180)) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX) * -1;
            pr.PlotY = fabs(pr.PlotY) * -1;
            break;
         case '4' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( deg2rad(360) - pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = cos( deg2rad(360) - pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX);
            pr.PlotY = fabs(pr.PlotY) * -1;
            break;
         case '5' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = cos( pr.GalLongitude) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX);
            pr.PlotY = fabs(pr.PlotY);
            break;
         case '6' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( deg2rad(180)-pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = cos( deg2rad(180)-pr.GalLongitude) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX) * -1;
            pr.PlotY = fabs(pr.PlotY);
            break;
         case '7' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( pr.GalLongitude -deg2rad(180) ) * pr.PlotX;
            pr.PlotX = cos( pr.GalLongitude -deg2rad(180) ) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX) * -1;
            pr.PlotY = fabs(pr.PlotY) * -1;
            break;
         case '8' :
            pr.PlotX = cos( pr.GalLatitude) * pr.DstLightYears;
            pr.PlotY = sin( deg2rad(360) - pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = cos( deg2rad(360) - pr.GalLongitude ) * pr.PlotX;
            pr.PlotX = fabs( pr.PlotX);
            pr.PlotY = fabs(pr.PlotY) * -1;
            break;
      }
      PXErr( PXPutDoub(  rHdl,  9, pr.PlotX));
      PXErr( PXPutDoub(  rHdl, 10, pr.PlotY));
      PXErr( PXPutDoub(  rHdl, 11, pr.PlotZ));
   }
   else
   {
      PXErr( PXPutBlank( rHdl, 9));
      PXErr( PXPutBlank( rHdl, 10));
      PXErr( PXPutBlank( rHdl, 11));
   }


   if( pr.PlotName[0] == 0)
   {
      if( pr.Bayer[0] != 0)
      {
         sprintf( pr.PlotName, "%s %s %s", strupr( pr.Bayer), pr.Constellation, pr.TempClass);
      }
      else
      {
         if( pr.Flamsteed )
            sprintf( pr.PlotName, "%d %s %s", pr.Flamsteed, pr.Constellation, pr.TempClass);
         else
            if( pr.DmZone && pr.DmNbr)
               sprintf( pr.PlotName, "DM%d:%d %s", pr.DmZone, pr.DmNbr, pr.TempClass);
            else
               sprintf( pr.PlotName, "BS%d %s", pr.StarNbr, pr.TempClass);
      }
      if( pr.StarCnt )
      {
         itoa( pr.StarCnt, str, 10);
         strcat( pr.PlotName, str);
      }
      PXErr( PXPutAlpha( rHdl, 7, pr.PlotName ));
   }

   PXErr( PXPutShort( rHdl,12, pr.Flamsteed));
   PXErr( PXPutAlpha( rHdl,13, pr.Bayer ));
   PXErr( PXPutShort( rHdl,14, pr.BayerSub));
   PXErr( PXPutAlpha( rHdl,15, pr.Constellation));
   PXErr( PXPutAlpha( rHdl,16, pr.DmSign));
   PXErr( PXPutShort( rHdl,17, pr.DmZone));
   PXErr( PXPutShort( rHdl,18, pr.DmNbr));
   PXErr( PXPutDoub(  rHdl,19, pr.DraperNbr));
   PXErr( PXPutAlpha( rHdl,20, pr.IrFlag));
   PXErr( PXPutAlpha( rHdl,21, pr.IrDataSource));
   PXErr( PXPutAlpha( rHdl,22, pr.DsCatCode));
   PXErr( PXPutAlpha( rHdl,23, pr.DsAdsNbr));
   PXErr( PXPutAlpha( rHdl,24, pr.DsComponent));
   PXErr( PXPutAlpha( rHdl,25, pr.VarDesignation));
   PXErr( PXPutShort( rHdl,26, pr.RaHrs1900));
   PXErr( PXPutShort( rHdl,27, pr.RaMin1900));
   PXErr( PXPutDoub(  rHdl,28, pr.RaSec1900));
   PXErr( PXPutAlpha( rHdl,29, pr.DecSgn1900));
   PXErr( PXPutShort( rHdl,30, pr.DecDeg1900));
   PXErr( PXPutShort( rHdl,31, pr.DecMin1900));
   PXErr( PXPutShort( rHdl,32, pr.DecSec1900));
   PXErr( PXPutShort( rHdl,33, pr.RaHrs2000));
   PXErr( PXPutShort( rHdl,34, pr.RaMin2000));
   PXErr( PXPutDoub(  rHdl,35, pr.RaSec2000));
   PXErr( PXPutAlpha( rHdl,36, pr.DecSgn2000));
   PXErr( PXPutShort( rHdl,37, pr.DecDeg2000));
   PXErr( PXPutShort( rHdl,38, pr.DecMin2000));
   PXErr( PXPutShort( rHdl,39, pr.DecSec2000));
   PXErr( PXPutDoub(  rHdl,40, pr.VisMag));
   PXErr( PXPutAlpha( rHdl,41, pr.VisMagCode));
   PXErr( PXPutDoub(  rHdl,42, pr.BvMag));
   PXErr( PXPutDoub(  rHdl,43, pr.UbMag));
   PXErr( PXPutDoub(  rHdl,44, pr.RiMag));
   PXErr( PXPutAlpha( rHdl,45, pr.RiCode));
   PXErr( PXPutAlpha( rHdl,46, pr.WilsonLumClass));
   PXErr( PXPutAlpha( rHdl,47, pr.TempClass));
   PXErr( PXPutAlpha( rHdl,48, pr.SpecClass));
   PXErr( PXPutDoub(  rHdl,49, pr.RaApm));
   PXErr( PXPutDoub(  rHdl,50, pr.DecApm));
   PXErr( PXPutAlpha( rHdl,51, pr.PlxCode));
   PXErr( PXPutShort( rHdl,52, pr.RadVel));
   PXErr( PXPutAlpha( rHdl,53, pr.RadVelCode));
   PXErr( PXPutAlpha( rHdl,54, pr.RotVelCode1));
   PXErr( PXPutShort( rHdl,55, pr.RotVel));
   PXErr( PXPutAlpha( rHdl,56, pr.RotVelCode2));
   PXErr( PXPutDoub(  rHdl,57, pr.DeltaMag));
   PXErr( PXPutAlpha( rHdl,58, pr.DeltaUncertainty));
   PXErr( PXPutDoub(  rHdl,59, pr.DeltaSep));
   PXErr( PXPutAlpha( rHdl,60, pr.DeltaId));
   PXErr( PXPutShort( rHdl,61, pr.StarCnt));
   PXErr( PXPutAlpha( rHdl,62, pr.Remarks));
}

void parse_rawrec(void)
{
   int i;

   pr.StarNbr = cvt_int( rr.StarNbr, 4);
   for( i=0; i<14; i++)
   {
      if( Exceptions[i] == pr.StarNbr)
         break;
   }
   if( i == 14)
   {
      pr.Flamsteed = cvt_int( rr.Flamsteed, 3);
      strcpy( pr.Bayer, BayerTable[cvt_int( rr.Bayer, 2)] );
      pr.BayerSub = cvt_int( rr.BayerSub, 2);
      cvt_str( rr.Constellation, pr.Constellation,3 );
      pr.PlotName[0] = 0;
   }
   else
   {
      pr.Flamsteed = 0;
      pr.Bayer[0] = 0;
      pr.BayerSub = 0;
      pr.Constellation[0] = 0;
      cvt_str((char*)&(rr.Flamsteed[1]), pr.PlotName, 9);
   }

   cvt_str( rr.DmSign, pr.DmSign, 1);
   pr.DmZone = cvt_int( rr.DmZone, 2);
   pr.DmNbr = cvt_int( rr.DmNbr, 5);
   pr.DraperNbr = cvt_flt( rr.Draper, 6, 0);
   cvt_str( rr.IrFlag, pr.IrFlag, 1);
   cvt_str( rr.IrDataSource, pr.IrDataSource, 1);
   cvt_str( rr.DblStarCatCode, pr.DsCatCode, 1);
   cvt_str( rr.AdsNbr, pr.DsAdsNbr, 5);
   cvt_str( rr.Component, pr.DsComponent, 2);
   cvt_str( rr.VarDesignation, pr.VarDesignation, 9);
   pr.RaHrs1900 = cvt_int( rr.RaHrs1900, 2);
   pr.RaMin1900 = cvt_int( rr.RaMin1900, 2);
   pr.RaSec1900 = cvt_flt( rr.RaSec1900, 4, 1);
   cvt_str( rr.DecSgn1900, pr.DecSgn1900, 1);
   pr.DecDeg1900 = cvt_int( rr.DecDeg1900, 2);
   pr.DecMin1900 = cvt_int( rr.DecMin1900, 2);
   pr.DecSec1900 = cvt_int( rr.DecSec1900, 2);
   pr.RaHrs2000 = cvt_int( rr.RaHrs2000, 2);
   pr.RaMin2000 = cvt_int( rr.RaMin2000, 2);
   pr.RaSec2000 = cvt_flt( rr.RaSec2000, 4, 1);
   cvt_str( rr.DecSgn2000, pr.DecSgn2000, 1);
   pr.DecDeg2000 = cvt_int( rr.DecDeg2000, 2);
   pr.DecMin2000 = cvt_int( rr.DecMin2000, 2);
   pr.DecSec2000 = cvt_int( rr.DecSec2000, 2);
   pr.GalLongitude = cvt_flt( rr.GalLongitude, 6, 2);
   pr.GalLatitude = cvt_flt( rr.GalLatitude, 6, 2);
   pr.VisMag = cvt_flt( rr.VisMag, 5, 2);
   cvt_str( rr.VisMagCode, pr.VisMagCode, 1);
   pr.BvMag = cvt_flt( rr.BvMag, 5, 2);
   pr.UbMag = cvt_flt( rr.UbMag, 5, 2);
   pr.RiMag = cvt_flt( rr.RiMag, 5, 2);
   cvt_str( rr.RiCode, pr.RiCode, 1);
   cvt_str( rr.WilsonLumClass, pr.WilsonLumClass, 2);
   cvt_str( rr.TempClass, pr.TempClass, 1);
   cvt_str( rr.SpecClass, pr.SpecClass,17);
   pr.RaApm = cvt_flt( rr.RaApm, 6, 3);
   pr.DecApm = cvt_flt( rr.DecApm, 6, 3);
   cvt_str( rr.PlxCode, pr.PlxCode, 1);
   pr.Plx = cvt_flt( rr.Plx, 5, 3);
   pr.RadVel = cvt_int( rr.RadVel, 4);
   cvt_str( rr.RadVelCode, pr.RadVelCode, 4);
   cvt_str( rr.RotVelCode1, pr.RotVelCode1, 1);
   pr.RotVel = cvt_int( rr.RotVel, 3);
   cvt_str( rr.RotVelCode2, pr.RotVelCode2, 1);
   pr.DeltaMag = cvt_flt( rr.DeltaMag, 4, 1);
   cvt_str( rr.DeltaUncertainty, pr.DeltaUncertainty, 1);
   pr.DeltaSep = cvt_flt( rr.DeltaSep, 6, 1);
   cvt_str( rr.DeltaId, pr.DeltaId, 4);
   pr.StarCnt = cvt_int( rr.StarCnt, 2);
   cvt_str( rr.Remark, pr.Remarks, 1);
}

int main(void)
{
   printf( "CVT_YBSC - Convert the Yale Bright Star Catalog fix length data files\n" );
   printf( "           (YALE.DAT and YALEREM.DAT to a Paradox 4.O file CATALOG.*\n" );
   atexit( exit_func );             // init cleanup func()

   printf( "\nInitializing the Paradox Engine..." );
   PXErr( PXSetDefaults( 128, 10, 10, 32, 20, PXDEFAULT ));
   PXErr( PXNetInit(NETDIR, NETTYPE, USERNAME) );
//   PXErr( PXTblEmpty( "starcatr" ));
   PXErr( PXTblEmpty( "starcatd" ));
   PXErr( PXTblOpen( "starcatd", &tHdl, 0, 0));
   PXErr( PXRecBufOpen( tHdl, &rHdl));

   pIn = fopen( "yale.dat", "r" );
   if(!pIn)
   {
      printf( "\nOPEN FAILED (YALE.DAT)" );
      return(1);
   }

   printf( "\n\n     IMPORTING DATA:          ");
   while( fgets( (char*)&(rr), sizeof(rr), pIn) != NULL)
   {
      rec_cnt++;
      printf( "\b\b\b\b\b%5d", rec_cnt);
      parse_rawrec();
      rawrec2buf();
      if( kbhit())
         break;
      PXErr( PXRecAppend( tHdl, rHdl));
   }
   fclose( pIn);
   PXErr( PXTblClose( tHdl));
/*
   PXErr( PXTblOpen( "starcatr", &tHdl, 0, 0));
   PXErr( PXRecBufOpen( tHdl, &rHdl));

   pIn = fopen( "yalerem.dat", "r" );
   if(!pIn)
   {
      printf( "\nOPEN FAILED (YALEREM.DAT)" );
      return(1);
   }

   printf( "\n\n     IMPORTING REMARKS:      ");
   rec_cnt = 0;
   while( fgets( (char*)&(rm), sizeof(rm), pIn) != NULL)
   {
      rec_cnt++;
      printf( "\b\b\b\b\b%5d", rec_cnt);
      xlat_remrec();
      if( kbhit())
         break;
      PXErr( PXRecAppend( tHdl, rHdl));
   }
   fclose( pIn);
   PXErr( PXTblClose( tHdl));
*/
   return(0);
}
